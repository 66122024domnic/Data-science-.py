# Student Performance Analysis

This is my first Data Science project using Python.

## What the project does

The program analyzes students' marks and calculates:

- Average mark
- Highest mark
- Lowest mark
- Number of students who passed
- Pass percentage
- Individual student grades

## Technologies Used

- Python
- Basic statistics
- Dictionaries
- Lists
- Loops
- Conditional statements

## Purpose

This project is part of my journey into Python and Data Science.

## Future Improvements

I plan to improve this project by using:

- NumPy
- pandas
- Matplotlib
- Real-world datasets
