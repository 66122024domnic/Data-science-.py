# Student Performance Analysis
# My first Data Science project

students = {
    "John": 78,
    "Mary": 65,
    "Peter": 45,
    "Jane": 82,
    "David": 56,
    "Ann": 91,
    "Brian": 38,
    "Lucy": 74
}

marks = list(students.values())

# Calculate statistics
average = sum(marks) / len(marks)
highest = max(marks)
lowest = min(marks)

# Count students who passed
passed = sum(1 for mark in marks if mark >= 50)
pass_percentage = (passed / len(marks)) * 100

# Display results
print("STUDENT PERFORMANCE ANALYSIS")
print("-" * 35)

for name, mark in students.items():
    if mark >= 70:
        grade = "A"
    elif mark >= 60:
        grade = "B"
    elif mark >= 50:
        grade = "C"
    elif mark >= 40:
        grade = "D"
    else:
        grade = "E"

    print(f"{name}: {mark} - Grade {grade}")

print("\nSUMMARY")
print("-" * 35)
print(f"Average mark: {average:.2f}")
print(f"Highest mark: {highest}")
print(f"Lowest mark: {lowest}")
print(f"Students who passed: {passed}")
print(f"Pass percentage: {pass_percentage:.2f}%")
